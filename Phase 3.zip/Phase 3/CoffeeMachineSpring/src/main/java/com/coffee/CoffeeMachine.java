package com.coffee;

public interface CoffeeMachine {
	public void rateOfCoffee();
	public void typeOfCoffee();
}
