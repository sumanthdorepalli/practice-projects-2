package practice_projects;
class DefAccessSpecifier {
    void display() {
        System.out.println("You are using default access specifier");
    }
}
public class modifiers {
	public static void main(String[] args) {
	    
	        System.out.println("Default Access Specifier");
	        DefAccessSpecifier obj = new DefAccessSpecifier();
	        obj.display();

	       
	        System.out.println("\nPrivate Access Specifier");
	        PriAccessSpecifier privateObj = new PriAccessSpecifier();
	       
	        System.out.println("\nProtected Access Specifier");
	        ProAccessSpecifier protectedObj = new ProAccessSpecifier();
	        protectedObj.display();

	      
	        System.out.println("\nPublic Access Specifier");
	        PubAccessSpecifier publicObj = new PubAccessSpecifier();
	        publicObj.display();
	    }
	}

	class PriAccessSpecifier {
	    private void display() {
	        System.out.println("You are using private access specifier");
	    }
	}

	class ProAccessSpecifier {
	    protected void display() {
	        System.out.println("This is protected access specifier");
	    }
	}

	class PubAccessSpecifier {
	    public void display() {
	        System.out.println("This is Public Access Specifier");
	    }
	
}
