package practice_projects;

public class ConstructorExample {

	    private int intValue;
	    private String stringValue;

	    public ConstructorExample() {
	        System.out.println("Default Constructor called");
	        intValue = 0;
	        stringValue = "Default";
	    }

	    public ConstructorExample(int intValue, String stringValue) {
	        System.out.println("Parameterized Constructor called");
	        this.intValue = intValue;
	        this.stringValue = stringValue;
	    }

	    public ConstructorExample(ConstructorExample other) {
	        System.out.println("Copy Constructor called");
	        this.intValue = other.intValue;
	        this.stringValue = other.stringValue;
	    }

	    public void display() {
	        System.out.println("Int Value: " + intValue);
	        System.out.println("String Value: " + stringValue);
	    }

	    public static void main(String[] args) {
	      
	        ConstructorExample defaultConstructorObj = new ConstructorExample();
	        ConstructorExample parameterizedConstructorObj = new ConstructorExample(42, "Parameterized");
	        ConstructorExample copyConstructorObj = new ConstructorExample(parameterizedConstructorObj);

	       
	        System.out.println("\nDetails of Object created using Default Constructor:");
	        defaultConstructorObj.display();

	        System.out.println("\nDetails of Object created using Parameterized Constructor:");
	        parameterizedConstructorObj.display();

	        System.out.println("\nDetails of Object created using Copy Constructor:");
	        copyConstructorObj.display();
	    }
	


}
