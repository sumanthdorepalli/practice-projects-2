package practice_projects;

public class innerClass {
	    private int outerVariable = 10;
	    
	    public class InnerClass {
	        private int innerVariable = 20;
	        
	        public void printValues(){
	            System.out.println("Outer Variable: " + outerVariable);
	            System.out.println("Inner Variable: " + innerVariable);
	        }
	    }
	    
	    public static void main(String[] args){
	    	innerClass outerObj = new innerClass();
	    	innerClass.InnerClass innerObj = outerObj.new InnerClass(); // creating an object of inner class
	        innerObj.printValues();
	    }
	
}
