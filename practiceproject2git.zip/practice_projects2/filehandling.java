package practice_projects2;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class filehandling {
	public static void main(String[] args) {
        String newfile = "D:\\sumanth.txt";

        // Write
        try {
            String content = "hi friends - This is the content that will be written to the file.";
            FileOutputStream data = new FileOutputStream(newfile);
            data.write(content.getBytes());
            data.close();
            System.out.println("Content has been written to the file.- write");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            
        }

        // Append
        try {
            String additionalContent = "\nmy name is sumanth - This content will be appended to the file.";
            FileWriter adata = new FileWriter(newfile, true);
            adata.write(additionalContent);
            adata.close();
            System.out.println("Content has been appended to the file.- append");
        } catch (IOException e) {
            System.out.println("An error occurred while appending to the file.");
            
        }

        // Reading
        try {
            FileReader rdata = new FileReader(newfile);
            BufferedReader read = new BufferedReader(rdata);
            String line;

            System.out.println("Contents of the file: - read");
            while ((line = read.readLine()) != null) {
                System.out.println(line);
            }

            read.close();
        } catch (IOException e) {
            System.out.println("An error occurred while reading from the file.");
            
        }
    }

}
