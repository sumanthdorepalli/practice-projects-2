package practice_projects2;

public class TryandCatch {
	public static void main(String[] args) {
	        try {
	            // Trying to perform an operation that may throw an exception
	            performOperation();
	        } catch (CustomException e) {
	            // Catching a custom exception thrown by performOperation()
	            System.out.println("Caught CustomException: " + e.getMessage());
	        } finally {
	            // Finally block executes whether an exception occurred or not
	            System.out.println("Finally block executed.");
	        }
	    }

	    // Method that throws a custom exception using the throw keyword
	    public static void performOperation() throws CustomException {
	        try {
	            int result = 10 / 0; // Trying to divide by zero to simulate an error
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            // Catching the ArithmeticException and throwing a custom exception
	            throw new CustomException("CustomException: Division by zero error occurred.");
	        }
	    }
	}

	// Custom exception class extending Exception
class CustomException extends Exception {
	public CustomException(String message) {
		super(message);
	    }
	


}
