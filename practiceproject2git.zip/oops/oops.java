package oops;


	// Abstraction using abstract class
	abstract class Animal {
	    // Abstract method
	    public abstract void makeSound();
	}

	// Inheritance - Dog class extends Animal class
	class Dog extends Animal {
	    // Encapsulation - private field
	    private String breed;

	    // Constructor
	    public Dog(String breed) {
	        this.breed = breed;
	    }

	    // Overriding abstract method from the parent class
	    @Override
	    public void makeSound() {
	        System.out.println("Woof! I'm a " + breed);
	    }

	    // Encapsulation - Getter and Setter for breed field
	    public String getBreed() {
	        return breed;
	    }

	    public void setBreed(String breed) {
	        this.breed = breed;
	    }

	    // Polymorphism - Method overloading
	    public void makeSound(int times) {
	        for (int i = 0; i < times; i++) {
	            System.out.println("Woof!");
	        }
	    }
	}

	public class oops {
	    public static void main(String[] args) {
	        // Object creation and usage
	        Dog myDog = new Dog("Labrador");
	        myDog.makeSound(); // Polymorphism - Calls overridden method
	        myDog.makeSound(3); // Polymorphism - Calls overloaded method

	        // Encapsulation - Accessing private field using getter and setter
	        System.out.println("Breed: " + myDog.getBreed());
	        myDog.setBreed("Golden Retriever");
	        System.out.println("New Breed: " + myDog.getBreed());
	    }
	}



