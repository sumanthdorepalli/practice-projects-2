package FileHandlin;
import java.io.*;
public class filehandling {
	    public static void main(String[] args) {
	        String fileName = "D:\\example.txt";

	        // Creating a file
	        try {
	            File file = new File(fileName);
	            if (file.createNewFile()) {
	                System.out.println("File created: " + file.getName());
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file.");
	            e.printStackTrace();
	        }

	        // Writing to a file
	        try {
	            FileWriter fileWriter = new FileWriter(fileName);
	            fileWriter.write("This is the content that will be written to the file.");
	            fileWriter.close();
	            System.out.println("Content has been written to the file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while writing to the file.");
	            e.printStackTrace();
	        }

	        // Reading from a file
	        try {
	            FileReader fileReader = new FileReader(fileName);
	            BufferedReader bufferedReader = new BufferedReader(fileReader);
	            String line;

	            System.out.println("Contents of the file:");
	            while ((line = bufferedReader.readLine()) != null) {
	                System.out.println(line);
	            }

	            bufferedReader.close();
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading from the file.");
	            e.printStackTrace();
	        }

	        // Updating a file
	        try {
	            FileWriter fileWriter = new FileWriter(fileName, true); // true for append mode
	            fileWriter.write("\nThis content will be appended to the file.");
	            fileWriter.close();
	            System.out.println("Content has been appended to the file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while appending to the file.");
	            e.printStackTrace();
	        }

	        // Deleting a file
	        try {
	            File file = new File(fileName);
	            if (file.delete()) {
	                System.out.println("File deleted successfully.");
	            } else {
	                System.out.println("Failed to delete the file.");
	            }
	        } catch (Exception e) {
	            System.out.println("An error occurred while deleting the file.");
	            e.printStackTrace();
	        }
	    }
	


}
