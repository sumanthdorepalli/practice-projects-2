package Singlelinkedlist;


class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class SinglyLinkedList {
	    private Node head;

	    SinglyLinkedList() {
	        this.head = null;
	    }

	    
	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            newNode.next = head;
	            head = newNode;
	        }
	    }

	   
	    public void displayList() {
	        Node current = head;
	        System.out.print("Linked List: ");
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	    public void delete(int data) {
	        Node current = head;
	        Node prev = null;

	        while (current != null && current.data != data) {
	            prev = current;
	            current = current.next;
	        }

	        if (current != null) {
	            if (prev != null) {
	                prev.next = current.next;
	            } else {
	                head = current.next;
	            }
	            System.out.println("Node with data " + data + " deleted.");
	        } else {
	            System.out.println("Node with data " + data + " not found.");
	        }
	    }
	}

	public class SinglrLinkedList {
	    public static void main(String[] args) {
	        SinglyLinkedList myList = new SinglyLinkedList();

	        myList.insert(5);
	        myList.insert(10);
	        myList.insert(15);
	        myList.insert(20);

	        myList.displayList(); 

	        myList.delete(10); 
	        myList.displayList(); 

	        myList.delete(100); 
	    }
	}


